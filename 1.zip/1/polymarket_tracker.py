"""
Polymarket BTC 5min 賠率追蹤器
==============================
使用 py-clob-client 官方 SDK

安裝:
    pip install py-clob-client requests

用法:
    python polymarket_tracker.py
    python polymarket_tracker.py --url https://polymarket.com/event/btc-updown-5m-1776173400
    python polymarket_tracker.py --slug btc-updown-5m-1776173400 --interval 5
"""

import argparse
import csv
import json
import os
import re
import sys
import time
from datetime import datetime, timezone

import requests
from py_clob_client.client import ClobClient

# ── 常數 ──────────────────────────────────────────────────────────────
CLOB_HOST = "https://clob.polymarket.com"
GAMMA_API = "https://gamma-api.polymarket.com"
CSV_FILE  = "polymarket_odds.csv"

MARKET_INTERVALS = {
    "1m":  60,
    "5m":  300,
    "15m": 900,
    "1h":  3600,
}


# ── Gamma API ─────────────────────────────────────────────────────────

def fetch_market_by_slug(slug: str) -> dict | None:
    """
    Gamma API /markets?slug=<slug>
    回傳 market dict，含 clobTokenIds / question / closed / endDate
    """
    try:
        r = requests.get(
            f"{GAMMA_API}/markets",
            params={"slug": slug},
            timeout=8,
        )
        r.raise_for_status()
        data = r.json()
        # 可能是 list 或 {"data": [...]}
        if isinstance(data, list) and data:
            return data[0]
        if isinstance(data, dict):
            inner = data.get("data") or data.get("markets") or []
            if inner:
                return inner[0]
    except Exception as e:
        print(f"  [Gamma] {e}")
    return None


def get_token_ids(market: dict) -> tuple[str | None, str | None]:
    """解析 clobTokenIds（可能是 list 或 JSON 字串）"""
    raw = market.get("clobTokenIds", [])
    if isinstance(raw, str):
        try:
            raw = json.loads(raw)
        except Exception:
            return None, None
    if isinstance(raw, list) and len(raw) >= 2:
        return str(raw[0]), str(raw[1])
    return None, None


# ── CLOB 即時賠率 ─────────────────────────────────────────────────────

def get_live_prices(
    client: ClobClient, yes_id: str, no_id: str
) -> tuple[float | None, float | None]:
    """
    get_midpoint() 回傳 order book 中間價，是最即時的賠率
    回傳格式: {"mid": "0.52"} 或純 float
    """
    def _mid(token_id: str) -> float | None:
        try:
            resp = client.get_midpoint(token_id)
            if isinstance(resp, dict):
                return float(resp.get("mid", resp.get("midpoint", 0)))
            return float(resp)
        except Exception:
            return None

    return _mid(yes_id), _mid(no_id)


# ── Slug 工具 ─────────────────────────────────────────────────────────

def parse_slug(slug: str) -> tuple[str, str, int | None]:
    """
    'btc-updown-5m-1776173400' → ('btc-updown', '5m', 1776173400)
    """
    m = re.match(r"^(.+?)-(\d+[mh])-(\d{9,})$", slug)
    if m:
        return m.group(1), m.group(2), int(m.group(3))
    m2 = re.match(r"^(.+?)-(\d{9,})$", slug)
    if m2:
        return m2.group(1), "", int(m2.group(2))
    return slug, "", None


def next_slug(slug: str) -> str:
    """
    下一場 slug：timestamp + interval 秒數（正確推算，不是亂加 1）
    btc-updown-5m-1776173400 → btc-updown-5m-1776173700
    """
    prefix, interval_str, ts = parse_slug(slug)
    if ts is None:
        raise ValueError(f"無法解析 slug: {slug}")
    step = MARKET_INTERVALS.get(interval_str, 300)
    new_ts = ts + step
    if interval_str:
        return f"{prefix}-{interval_str}-{new_ts}"
    return f"{prefix}-{new_ts}"


def align_to_current(slug: str) -> str:
    """
    用現在 UTC 時間對齊到最近一個「已開始但未結束」的場次
    如果當前場次已結束，自動跳到下一場
    """
    prefix, interval_str, ts = parse_slug(slug)
    if ts is None:
        return slug
    
    step = MARKET_INTERVALS.get(interval_str, 300)
    now_ts = int(datetime.now(timezone.utc).timestamp())
    
    # 向下取整到最近的間隔邊界（例如 5m = 300秒）
    aligned_ts = (now_ts // step) * step
    
    # ✅ 關鍵改進：如果對齊後的場次「已經結束」，跳到下一場
    # 場次結束時間 = 開始時間 + step
    if now_ts >= aligned_ts + step:
        aligned_ts += step
    
    if interval_str:
        return f"{prefix}-{interval_str}-{aligned_ts}"
    return f"{prefix}-{aligned_ts}"


def is_closed(market: dict) -> bool:
    if market.get("closed") is True:
        return True
    if market.get("active") is False:
        return True
    end = market.get("endDate") or market.get("end_date_iso") or ""
    if end:
        try:
            end_dt = datetime.fromisoformat(end.replace("Z", "+00:00"))
            return datetime.now(timezone.utc) > end_dt
        except Exception:
            pass
    return False


# ── CSV ───────────────────────────────────────────────────────────────

def init_csv(path: str):
    if not os.path.exists(path):
        with open(path, "w", newline="", encoding="utf-8") as f:
            csv.writer(f).writerow([
                "timestamp", "slug", "question",
                "yes_token_id", "no_token_id",
                "yes_price", "no_price", "market_closed",
            ])
        print(f"  📄 建立 CSV: {path}")


def append_csv(path: str, row: list):
    with open(path, "a", newline="", encoding="utf-8") as f:
        csv.writer(f).writerow(row)


# ── 主迴圈 ────────────────────────────────────────────────────────────

def track(start_slug: str, interval_sec: int = 1, auto_align: bool = True):
    # Level 0 client，純讀取不需要私鑰
    client = ClobClient(CLOB_HOST)
    status = client.get_ok()
    print(f"  🔗 CLOB 狀態: {status}")

    init_csv(CSV_FILE)

    if auto_align:
        aligned = align_to_current(start_slug)
        if aligned != start_slug:
            print(f"  ⏱️  對齊當前場次: {aligned}")
        start_slug = aligned

    current_slug = start_slug
    fail_count = 0

    print(f"\n{'='*62}")
    print(f"  🚀 追蹤中  間隔={interval_sec}s  輸出={CSV_FILE}")
    print(f"{'='*62}\n")

    while True:
        # Step 1: 從 Gamma 取 token_id
        print(f"🔍 {current_slug}")
        market = fetch_market_by_slug(current_slug)

        if market is None:
            fail_count += 1
            wait = min(5 * fail_count, 60)
            print(f"  ❌ 找不到市場，{wait}s 後重試 ({fail_count})")
            if fail_count >= 12:
                # 超過 1 分鐘還沒開，強制跳下一場
                print(f"  ⏭️  強制跳下一場")
                current_slug = next_slug(current_slug)
                fail_count = 0
            time.sleep(wait)
            continue

        fail_count = 0
        yes_id, no_id = get_token_ids(market)
        question = market.get("question", current_slug)

        if not yes_id or not no_id:
            print(f"  ⚠️  無 token_id，跳過")
            current_slug = next_slug(current_slug)
            time.sleep(3)
            continue

        print(f"  📌 {question}")
        print(f"  YES token: …{yes_id[-12:]}")
        print(f"  NO  token: …{no_id[-12:]}")
        print(f"  {'─'*58}")

        # Step 2: 每 interval_sec 記錄一次
        while True:
            # 重查 market 狀態
            fresh = fetch_market_by_slug(current_slug)
            if fresh:
                market = fresh

            closed = is_closed(market)
            yes_p, no_p = get_live_prices(client, yes_id, no_id)

            ts      = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            yes_str = f"{yes_p:.4f}" if yes_p is not None else "N/A"
            no_str  = f"{no_p:.4f}"  if no_p  is not None else "N/A"
            icon    = "🔴" if closed else "🟢"

            print(f"  {ts}  YES={yes_str}  NO={no_str}  {icon}")

            append_csv(CSV_FILE, [
                ts, current_slug, question,
                yes_id, no_id,
                yes_str, no_str, closed,
            ])

            if closed:
                print(f"\n  ✅ 結算完畢，切換下一場\n")
                break

            time.sleep(interval_sec)

        # Step 3: 推算下一場
        try:
            current_slug = next_slug(current_slug)
        except ValueError as e:
            print(f"  ❌ {e}")
            break

        print(f"  ⏭️  下一場: {current_slug}\n")
        time.sleep(2)


# ── CLI ───────────────────────────────────────────────────────────────

def main():
    global CSV_FILE  # ← 必須在第一行！
    
    ap = argparse.ArgumentParser(description="Polymarket 賠率追蹤器")
    ap.add_argument("--slug",     default="btc-updown-5m-1776173400",
                    help="起始 slug（預設自動對齊當前場次）")
    ap.add_argument("--url",      default=None,
                    help="直接貼網址，自動擷取 slug")
    ap.add_argument("--interval", type=int, default=1,
                    help="記錄間隔秒數（預設 1）")
    ap.add_argument("--csv",      default=CSV_FILE,
                    help=f"輸出 CSV（預設 {CSV_FILE}）")
    ap.add_argument("--no-align", action="store_true",
                    help="不自動對齊當前場次")
    args = ap.parse_args()

    CSV_FILE = args.csv

    slug = args.slug
    if args.url:
        slug = args.url.rstrip("/").split("/")[-1]
        print(f"  📎 擷取 slug: {slug}")

    try:
        track(
            start_slug=slug,
            interval_sec=args.interval,
            auto_align=not args.no_align,
        )
    except KeyboardInterrupt:
        print(f"\n\n⛔ 停止。CSV: {CSV_FILE}")
        sys.exit(0)

if __name__ == "__main__":
    main()