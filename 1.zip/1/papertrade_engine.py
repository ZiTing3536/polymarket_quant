#!/usr/bin/env python3
"""
Polymarket Paper Trading Engine v3
=====================================
架構改動：
  1. 合約一出現立即預掛 YES + NO 限價單（各取當前時段 EV 最高的入場價）
  2. 信號互斥：每個 sample 只屬於一個價格層，不重疊，EV 不虛高
  3. 時間特徵：夜間/日間/晚間三個獨立模型
  4. 雙重計數修復：每個合約只被 update 一次
  5. 固定 3% risk/bet，每合約 YES + NO 各一筆（最多 6%）

用法:
    python papertrade_engine.py --backfill
    python papertrade_engine.py --backfill --capital 1000 --risk 0.03
    python papertrade_engine.py --backfill --debug
"""

import argparse
import csv
import math
import os
import sys
import time
from collections import defaultdict
from dataclasses import dataclass, field
from datetime import datetime
from typing import Optional

# ─────────────────────────────────────────────────────────────────────────────
# ANSI 顏色系統 — 專業量化交易終端風格
# ─────────────────────────────────────────────────────────────────────────────

class C:
    """ANSI color codes — Bloomberg/quant terminal aesthetic"""
    # Reset
    R   = "\033[0m"
    # Text styles
    B   = "\033[1m"       # Bold
    DIM = "\033[2m"       # Dim
    IT  = "\033[3m"       # Italic
    UL  = "\033[4m"       # Underline
    # Foreground colors
    BLK = "\033[30m"
    RED = "\033[31m"
    GRN = "\033[32m"
    YLW = "\033[33m"
    BLU = "\033[34m"
    MAG = "\033[35m"
    CYN = "\033[36m"
    WHT = "\033[37m"
    # Bright variants
    BBLK = "\033[90m"
    BRED = "\033[91m"
    BGRN = "\033[92m"
    BYLW = "\033[93m"
    BBLU = "\033[94m"
    BMAG = "\033[95m"
    BCYN = "\033[96m"
    BWHT = "\033[97m"
    # Background
    BG_BLK  = "\033[40m"
    BG_RED  = "\033[41m"
    BG_GRN  = "\033[42m"
    BG_YLW  = "\033[43m"
    BG_BLU  = "\033[44m"
    BG_CYN  = "\033[46m"
    # Semantic aliases
    PROFIT  = "\033[92m"    # Bright green
    LOSS    = "\033[91m"    # Bright red
    NEUTRAL = "\033[37m"    # White
    SIGNAL  = "\033[96m"    # Bright cyan — signal/model info
    ORDER   = "\033[93m"    # Bright yellow — order events
    FILL    = "\033[92m"    # Bright green — fills
    EXPIRE  = "\033[90m"    # Dark gray — expired
    SKIP    = "\033[90m"    # Dark gray — skipped
    HEADER  = "\033[1;97m"  # Bold white — headers
    LABEL   = "\033[2;37m"  # Dim white — labels
    VALUE   = "\033[97m"    # Bright white — values
    WARN    = "\033[33m"    # Yellow — warnings
    SEP     = "\033[2;34m"  # Dim blue — separators

def pnl_color(pnl: float) -> str:
    if pnl > 0:   return C.PROFIT
    if pnl < 0:   return C.LOSS
    return C.NEUTRAL

def wr_color(wr: float) -> str:
    if wr >= 85:  return C.PROFIT
    if wr >= 70:  return C.YLW
    return C.LOSS

def fmt_pnl(pnl: float, width: int = 9) -> str:
    sign = "+" if pnl >= 0 else ""
    return f"{pnl_color(pnl)}{C.B}{sign}{pnl:.2f}{C.R}"

def fmt_pct(pct: float, width: int = 7) -> str:
    sign = "+" if pct >= 0 else ""
    return f"{pnl_color(pct)}{sign}{pct:.2f}%{C.R}"

def fmt_wr(wr: float) -> str:
    return f"{wr_color(wr)}{C.B}{wr:.1f}%{C.R}"

def sep_line(char: str = "─", width: int = 68) -> str:
    return f"{C.SEP}{char * width}{C.R}"


# ─────────────────────────────────────────────────────────────────────────────
# 常數
# ─────────────────────────────────────────────────────────────────────────────
CSV_FILE      = "polymarket_odds.csv"
TRADE_LOG     = "papertrade_log.csv"
MODEL_LOG     = "model_updates.csv"
REFRESH_SEC   = 1
CONTRACT_DUR  = 300
DASHBOARD_SEC = 30


def _safe_float(val, default=None):
    """float() に NaN/N/A/空文字などの不正値を渡されても落ちない安全版"""
    try:
        f = float(val)
        return f if (f == f) else default   # NaN check: NaN != NaN
    except (ValueError, TypeError):
        return default



# ─────────────────────────────────────────────────────────────────────────────
# 貝氏數學
# ─────────────────────────────────────────────────────────────────────────────

def _lgamma(x: float) -> float:
    if x < 0.5:
        return math.log(math.pi / math.sin(math.pi * x)) - _lgamma(1 - x)
    x -= 1
    c = [0.99999999999980993, 676.5203681218851, -1259.1392167224028,
         771.32342877765313, -176.61502916214059, 12.507343278686905,
         -0.13857109526572012, 9.9843695780195716e-6, 1.5056327351493116e-7]
    a = c[0]
    for i in range(1, 9):
        a += c[i] / (x + i)
    t = x + 7.5
    return 0.5 * math.log(2 * math.pi) + (x + 0.5) * math.log(t) - t + math.log(a)


def _beta_inc(a: float, b: float, x: float) -> float:
    if x <= 0: return 0.0
    if x >= 1: return 1.0
    if x > (a + 1) / (a + b + 2):
        return 1 - _beta_inc(b, a, 1 - x)
    lbeta = _lgamma(a) + _lgamma(b) - _lgamma(a + b)
    front = math.exp(a * math.log(x) + b * math.log(1 - x) - lbeta) / a
    # Lentz continued fraction: even and odd terms iterated separately
    # even term: d_{2m}   = m*(b-m)*x / ((a+2m-1)*(a+2m))
    # odd  term: d_{2m+1} = -(a+m)*(a+b+m)*x / ((a+2m)*(a+2m+1))
    c, d = 1.0, 1 - (a + b) * x / (a + 1)
    d = 1 / (d if abs(d) > 1e-30 else 1e-30)
    cf = d
    for m in range(1, 201):
        # even term
        num_e = m * (b - m) * x / ((a + 2*m - 1) * (a + 2*m))
        d = 1 + num_e * d;  d = 1 / (d if abs(d) > 1e-30 else 1e-30)
        c = 1 + num_e / (c if abs(c) > 1e-30 else 1e-30)
        cf *= c * d
        # odd term
        num_o = -(a + m) * (a + b + m) * x / ((a + 2*m) * (a + 2*m + 1))
        d = 1 + num_o * d;  d = 1 / (d if abs(d) > 1e-30 else 1e-30)
        c = 1 + num_o / (c if abs(c) > 1e-30 else 1e-30)
        cf *= c * d
        if abs(c * d - 1) < 1e-10:
            break
    return min(1.0, max(0.0, front * cf))


def beta_quantile(a: float, b: float, p: float) -> float:
    lo, hi, mid = 0.0, 1.0, a / (a + b)
    for _ in range(80):
        v = _beta_inc(a, b, mid)
        if abs(v - p) < 1e-9: break
        if v < p: lo = mid
        else:     hi = mid
        mid = (lo + hi) / 2
    return mid


# ─────────────────────────────────────────────────────────────────────────────
# 信號定義 — 互斥價格層 × 時間分段
#
# 設計原則：
#   每個 sample 只屬於一個 (side, price_tier, hour_bucket) 組合
#   → 模型之間沒有重疊，EV 不虛高
#
# YES 入場邏輯：
#   在 yes_p=0.80/0.85/0.90 預掛限價
#   合約開始後等價格下來成交（或合約結束作廢）
#
# NO 入場邏輯：
#   在 yes_p=0.20/0.15/0.10 預掛 NO 限價（no_p=0.80/0.85/0.90）
#   合約開始後等 yes 價格跌下來成交
#
# 每條信號的 entry_price = 限價掛單位置
# fn = 判斷某個 tick 是否屬於此模型的訓練樣本
# ─────────────────────────────────────────────────────────────────────────────

# 時間分段（UTC 小時）
HOUR_BUCKETS = [
    ("夜間 00-08", 0,  8),
    ("日間 08-16", 8,  16),
    ("晚間 16-24", 16, 24),
]

def hour_bucket(h: int) -> str:
    for name, lo, hi in HOUR_BUCKETS:
        if lo <= h < hi:
            return name
    return "晚間 16-24"

# 進度分段（互斥，每個 sample 只屬於一個）
PROGRESS_BUCKETS = [
    ("早段<0.33",      0.00, 0.33),
    ("中段0.33-0.66",  0.33, 0.66),
    ("晚段≥0.66",      0.66, 1.01),
]

def progress_bucket(p: float) -> str:
    for name, lo, hi in PROGRESS_BUCKETS:
        if lo <= p < hi:
            return name
    return "晚段≥0.66"

# 漂移分段（互斥）
def drift_bucket(d: float) -> str:
    if d > 0.005:  return "上升>0.005"
    if d < -0.005: return "下降<-0.005"
    return "穩定±0.005"

DRIFT_BUCKET_NAMES = ["上升>0.005", "穩定±0.005", "下降<-0.005"]

# YES 價格層
YES_PRICE_TIERS = [
    ("YES@0.90", 0.90, 0.90, 0.93),
    ("YES@0.85", 0.85, 0.85, 0.90),
    ("YES@0.80", 0.80, 0.80, 0.85),
]

# NO 價格層
NO_PRICE_TIERS = [
    ("NO@0.90",  0.90, 0.07, 0.10),
    ("NO@0.85",  0.85, 0.10, 0.15),
    ("NO@0.80",  0.80, 0.15, 0.20),
]

def build_signal_key(side, tier, hb, pb, db):
    return f"{side}::{tier}::{hb}::{pb}::{db}"


# ─────────────────────────────────────────────────────────────────────────────
# 特徵樣本
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class Sample:
    ts:          str
    slug:        str
    yes_p:       float
    no_p:        float
    drift:       float = 0.0       # yes_p - prev_yes_p
    drift_abs:   float = 0.0
    cum_drift:   float = 0.0       # yes_p - first_yes_p
    drift_accel: float = 0.0
    progress:    float = 0.5       # 0.0 ~ 1.0
    uncertainty: float = 0.5       # 1 - |yes_p - 0.5| * 2
    hour:        int   = 0
    outcome:     Optional[int] = None


def make_sample(ts, slug, yes_p, no_p,
                drift=0.0, cum_drift=0.0, drift_accel=0.0,
                progress=0.5, outcome=None) -> Sample:
    try:
        h = datetime.fromisoformat(ts.replace(" ", "T")).hour
    except Exception:
        h = 0
    return Sample(
        ts=ts, slug=slug, yes_p=yes_p, no_p=no_p,
        drift=drift, drift_abs=abs(drift),
        cum_drift=cum_drift, drift_accel=drift_accel,
        progress=round(progress, 4),
        uncertainty=round(1 - abs(yes_p - 0.5) * 2, 4),
        hour=h, outcome=outcome,
    )


# ─────────────────────────────────────────────────────────────────────────────
# 貝氏模型 — 每個 (side, price_tier, hour_bucket) 獨立
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class TierModel:
    key:          str
    side:         str
    tier_name:    str
    entry_price:  float
    hbucket:      str        # 時間分段
    pbucket:      str        # 進度分段
    dbucket:      str        # 漂移分段
    yes_lo:       float
    yes_hi:       float
    alpha0:       float = 2.0
    beta0:        float = 2.0
    wins:         int   = 0
    losses:       int   = 0

    @property
    def a(self):         return self.alpha0 + self.wins
    @property
    def b(self):         return self.beta0  + self.losses
    @property
    def n(self):         return self.wins + self.losses
    @property
    def post_mean(self): return self.a / (self.a + self.b)
    @property
    def ci_lo(self):     return beta_quantile(self.a, self.b, 0.025)
    @property
    def ci_hi(self):     return beta_quantile(self.a, self.b, 0.975)
    @property
    def ci_width(self):  return self.ci_hi - self.ci_lo
    @property
    def reliability(self):
        w = self.ci_width
        return "高" if w < 0.05 else "中" if w < 0.15 else "低"

    def matches_sample(self, s: Sample) -> bool:
        """此 sample 是否屬於這個模型（互斥，每個 sample 只屬於一個）"""
        if hour_bucket(s.hour) != self.hbucket:       return False
        if not (self.yes_lo <= s.yes_p < self.yes_hi): return False
        if progress_bucket(s.progress) != self.pbucket: return False
        if drift_bucket(s.drift) != self.dbucket:       return False
        return True

    def update(self, outcome: int):
        """YES 模型：outcome=1→win；NO 模型：outcome=0→win"""
        if self.side == "YES":
            if outcome == 1: self.wins   += 1
            else:            self.losses += 1
        else:
            if outcome == 0: self.wins   += 1
            else:            self.losses += 1

    def ev(self) -> float:
        """保守 EV（用 ci_lo）：EV = ci_lo * payout - (1 - ci_lo)"""
        p = self.entry_price
        if not (0.001 < p < 0.999): return -999.0
        payout = (1.0 - p) / p
        return self.ci_lo * payout - (1.0 - self.ci_lo)


def build_all_models(alpha0: float, beta0: float) -> dict:
    """建立所有 (side × tier × hour × progress × drift) 模型
    每個 sample 只屬於一個模型，完全互斥
    總數：3 tier × 3 hour × 3 progress × 3 drift × 2 side = 162 條"""
    models = {}
    for hname, _, _ in HOUR_BUCKETS:
        for pname, plo, phi in PROGRESS_BUCKETS:
            for dname in DRIFT_BUCKET_NAMES:
                for tier_name, entry_price, yes_lo, yes_hi in YES_PRICE_TIERS:
                    key = build_signal_key("YES", tier_name, hname, pname, dname)
                    models[key] = TierModel(
                        key=key, side="YES", tier_name=tier_name,
                        entry_price=entry_price,
                        hbucket=hname, pbucket=pname, dbucket=dname,
                        yes_lo=yes_lo, yes_hi=yes_hi,
                        alpha0=alpha0, beta0=beta0,
                    )
                for tier_name, entry_price, yes_lo, yes_hi in NO_PRICE_TIERS:
                    key = build_signal_key("NO", tier_name, hname, pname, dname)
                    models[key] = TierModel(
                        key=key, side="NO", tier_name=tier_name,
                        entry_price=entry_price,
                        hbucket=hname, pbucket=pname, dbucket=dname,
                        yes_lo=yes_lo, yes_hi=yes_hi,
                        alpha0=alpha0, beta0=beta0,
                    )
    return models


# ─────────────────────────────────────────────────────────────────────────────
# 合約狀態
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class ContractState:
    slug:         str
    obs:          list = field(default_factory=list)   # [(ts, yes_p, no_p)]
    closed:       bool = False
    outcome:      Optional[int]   = None
    start_ts_sec: Optional[float] = None

    def _slug_start_ts(self) -> Optional[float]:
        import re as _re
        m = _re.search(r'-(\d{9,})$', self.slug)
        return float(m.group(1)) if m else None

    def add(self, ts: str, yes_p: float, no_p: float):
        self.obs.append((ts, yes_p, no_p))
        if self.start_ts_sec is None:
            self.start_ts_sec = self._slug_start_ts()
            if self.start_ts_sec is None:
                try:
                    self.start_ts_sec = datetime.fromisoformat(
                        ts.replace(" ", "T")).timestamp()
                except Exception:
                    pass

    def prev_yes_p(self) -> Optional[float]:
        """前一個 tick 的 yes_p（用於跨 tick 成交判斷）"""
        if len(self.obs) >= 2:
            return self.obs[-2][1]
        return None

    def all_samples(self) -> list:
        """用於 rolling update：不含結算 tick，包含完整特徵"""
        if self.outcome is None or len(self.obs) < 2:
            return []
        obs = self.obs[:-1]   # 排除結算 tick
        n   = len(obs)
        out = []
        for i, (ts, yp, np_) in enumerate(obs):
            ypp         = obs[i-1][1] if i > 0 else yp
            y0          = obs[0][1]
            drift       = yp - ypp
            drift_accel = 0.0
            if i >= 2:
                drift_accel = drift - (ypp - obs[i-2][1])
            out.append(make_sample(
                ts, self.slug, yp, np_,
                drift=drift, cum_drift=yp - y0,
                drift_accel=drift_accel,
                progress=i / n if n > 0 else 0.5,
                outcome=self.outcome,
            ))
        return out


# ─────────────────────────────────────────────────────────────────────────────
# 紙上交易記錄
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class PaperTrade:
    id:              int
    slug:            str
    model_key:       str
    side:            str
    tier_name:       str
    entry_ts:        str        # 預掛時間
    limit_price:     float      # 限價（= 模型 entry_price）
    stake:           float
    post_mean_entry: float
    ev_entry:        float
    filled:          bool           = False
    fill_ts:         Optional[str]  = None
    exit_ts:         Optional[str]  = None
    outcome:         Optional[int]  = None
    pnl:             Optional[float] = None
    pnl_pct_capital: Optional[float] = None

    @property
    def settled(self): return self.outcome is not None
    @property
    def expired(self): return self.settled and not self.filled

    def settle(self, outcome: int, exit_ts: str, capital: float):
        self.outcome = outcome
        self.exit_ts = exit_ts
        if not self.filled:
            self.pnl             = 0.0
            self.pnl_pct_capital = 0.0
            return
        won = (self.side == "YES" and outcome == 1) or \
              (self.side == "NO"  and outcome == 0)
        p   = self.limit_price
        self.pnl = self.stake * (1.0 - p) / p if won else -self.stake
        self.pnl_pct_capital = self.pnl / capital * 100 if capital > 0 else 0.0


# ─────────────────────────────────────────────────────────────────────────────
# 主引擎
# ─────────────────────────────────────────────────────────────────────────────

class PaperTradingEngine:

    def __init__(
        self,
        csv_file:  str   = CSV_FILE,
        capital:   float = 1000.0,
        risk_pct:  float = 0.03,
        alpha0:    float = 2.0,
        beta0:     float = 2.0,
        min_ev:    float = 0.005,
        min_n:     int   = 10,
        debug:     bool  = False,
    ):
        self.csv_file    = csv_file
        self.initial_cap = capital
        self.capital     = capital
        self.risk_pct    = risk_pct
        self.min_ev      = min_ev
        self.min_n       = min_n
        self.debug       = debug

        # 所有模型：side × tier × hour_bucket
        self.models: dict[str, TierModel] = build_all_models(alpha0, beta0)

        self.contracts:      dict[str, ContractState] = {}
        self.open_trades:    dict[str, PaperTrade]    = {}
        self.closed_trades:  list[PaperTrade]          = []
        self.trade_id        = 0
        self.last_row        = 0

        # 雙重計數修復：記錄已 update 過的合約
        self.updated_slugs: set = set()

        self._init_logs()

    # ── 日誌初始化 ─────────────────────────────────────────────────────

    def _init_logs(self):
        if not os.path.exists(TRADE_LOG):
            with open(TRADE_LOG, "w", newline="", encoding="utf-8") as f:
                csv.writer(f).writerow([
                    "id", "slug", "model_key", "side", "tier",
                    "entry_ts", "limit_price", "stake",
                    "post_mean_entry", "ev_entry",
                    "filled", "fill_ts", "exit_ts", "outcome",
                    "pnl", "pnl_pct_capital",
                ])
        if not os.path.exists(MODEL_LOG):
            with open(MODEL_LOG, "w", newline="", encoding="utf-8") as f:
                csv.writer(f).writerow([
                    "ts", "model_key", "side", "tier", "hbucket",
                    "n", "wins", "losses",
                    "post_mean", "ci_lo", "ci_hi", "reliability", "slug",
                ])

    # ── Backfill ───────────────────────────────────────────────────────

    def backfill(self, rows: list[dict]):
        print(f"\n  [BACKFILL] 回填訓練中... ({len(rows)} 筆)")
        by_slug = defaultdict(list)
        for r in rows:
            by_slug[r["slug"]].append(r)

        trained = skipped = 0
        for slug, entries in by_slug.items():
            entries.sort(key=lambda x: x["timestamp"])
            closed_row = next(
                (e for e in entries
                 if e.get("market_closed", "").strip().upper() in ("TRUE", "1")),
                None)
            if not closed_row:
                skipped += 1; continue
            try:
                outcome = 1 if float(closed_row["yes_price"]) > 0.5 else 0
            except Exception:
                skipped += 1; continue

            closed_idx = entries.index(closed_row)
            valid = entries[:closed_idx]   # 不含結算行
            if len(valid) < 2:
                skipped += 1; continue

            # 更新模型（每個合約只算一次）
            for i, row in enumerate(valid):
                yp  = _safe_float(row.get("yes_price"))
                np_ = _safe_float(row.get("no_price"))
                if yp is None or not (0 < yp < 1):
                    continue
                if np_ is None:
                    np_ = 1 - yp
                ypp_raw = _safe_float(valid[i-1].get("yes_price")) if i > 0 else None
                ypp     = ypp_raw if ypp_raw is not None else yp
                y0_raw  = _safe_float(valid[0].get("yes_price"))
                y0      = y0_raw if y0_raw is not None else yp
                drift_accel = 0.0
                if i >= 2:
                    yp2 = _safe_float(valid[i-2].get("yes_price"))
                    if yp2 is not None:
                        drift_accel = (yp - ypp) - (ypp - yp2)
                s = make_sample(
                    row["timestamp"], slug, yp, np_,
                    drift=yp - ypp,
                    cum_drift=yp - y0,
                    drift_accel=drift_accel,
                    progress=i / len(valid),
                    outcome=outcome,
                )
                for model in self.models.values():
                    if model.matches_sample(s):
                        model.update(outcome)

            self.updated_slugs.add(slug)
            trained += 1

        print(f"    BACKFILL DONE：{trained} 合約，{skipped} 跳過")
        self._print_model_table()

    # ── 增量讀取 ────────────────────────────────────────────────────────

    def _read_new_rows(self) -> list[dict]:
        rows = []
        try:
            with open(self.csv_file, "r", encoding="utf-8") as f:
                for i, row in enumerate(csv.DictReader(f)):
                    if i >= self.last_row:
                        rows.append(row)
            self.last_row += len(rows)
        except FileNotFoundError:
            pass
        except Exception as e:
            print(f"  [讀取錯誤] {e}")
        return rows

    # ── 處理單行 ────────────────────────────────────────────────────────

    def process_row(self, row: dict):
        slug   = row.get("slug", "").strip()
        ts     = row.get("timestamp", "").strip()
        closed = row.get("market_closed", "").strip().upper() in ("TRUE", "1")

        try:
            yes_p = float(row.get("yes_price", 0))
            no_p  = float(row.get("no_price",  0))
        except (ValueError, TypeError):
            return

        if not slug or not ts or not (0 < yes_p < 1):
            return

        # 建立合約
        is_new = slug not in self.contracts
        if is_new:
            self.contracts[slug] = ContractState(slug=slug)
        contract = self.contracts[slug]
        if contract.closed:
            return

        if closed:
            outcome = 1 if yes_p > 0.5 else 0
            contract.closed  = True
            contract.outcome = outcome
            contract.add(ts, yes_p, no_p)
            self._settle_contract(slug, outcome, ts)
        else:
            contract.add(ts, yes_p, no_p)

            # 預掛限價單（只在合約第一次出現時執行）
            if is_new:
                self._place_opening_orders(slug, ts)

            # 檢查現有掛單是否成交
            self._check_fills(slug, ts, yes_p, contract)

    # ── 預掛限價單（合約開始時）────────────────────────────────────────

    # 跳過的時段（UTC 小時）
    # 08:00-09:59 EST = 13:00-14:59 UTC（美股開盤）
    # 15:00-15:59 EST = 20:00-20:59 UTC（美股收盤前）
    SKIP_UTC_HOURS = {13, 14, 20}

    def _is_skip_hour(self, ts: str) -> bool:
        try:
            h = datetime.fromisoformat(ts.replace(" ", "T")).hour
            if h in self.SKIP_UTC_HOURS:
                return True
        except Exception:
            pass
        return False

    def _place_opening_orders(self, slug: str, ts: str):
        """
        合約出現時，立即從模型中找出當前時段 EV 最高的
        YES 入場價和 NO 入場價，各預掛一筆限價單。
        """
        # 跳過不穩定時段（美股開盤 / 收盤前）
        if self._is_skip_hour(ts):
            try:
                h_utc = datetime.fromisoformat(ts.replace(" ", "T")).hour
                h_est = h_utc - 5
                if h_est < 0: h_est += 24
                print(f"{C.SKIP}  ◼ SKIP  {C.WARN}{h_est:02d}:xx EST{C.SKIP} / {h_utc:02d}:xx UTC  {slug[-25:]}{C.R}")
            except Exception:
                pass
            return

        try:
            h = datetime.fromisoformat(ts.replace(" ", "T")).hour
        except Exception:
            h = 0
        hb = hour_bucket(h)

        # 分別找 YES 和 NO 的最佳入場
        for side, tiers in [("YES", YES_PRICE_TIERS), ("NO", NO_PRICE_TIERS)]:
            best_ev    = self.min_ev
            best_model = None

            # 合約剛開始：progress≈0，drift≈0（無前一個 tick）
            pb = progress_bucket(0.0)
            db = drift_bucket(0.0)

            for tier_name, entry_price, _, _ in tiers:
                key   = build_signal_key(side, tier_name, hb, pb, db)
                model = self.models.get(key)
                if model is None or model.n < self.min_n:
                    continue
                ev = model.ev()
                if ev > best_ev:
                    best_ev    = ev
                    best_model = model

            # 若早段無符合，也搜尋其他進度段（因為合約可能被加入時已過早段）
            if best_model is None:
                for pname, _, _ in PROGRESS_BUCKETS:
                    for dname in DRIFT_BUCKET_NAMES:
                        for tier_name, _, _, _ in tiers:
                            key   = build_signal_key(side, tier_name, hb, pname, dname)
                            model = self.models.get(key)
                            if model is None or model.n < self.min_n:
                                continue
                            ev = model.ev()
                            if ev > best_ev:
                                best_ev    = ev
                                best_model = model

            if best_model is None:
                # 找出最接近的模型（即使 EV 不足），幫助診斷
                best_cand_ev   = -999.0
                best_cand_name = "無樣本"
                for pname, _, _ in PROGRESS_BUCKETS:
                    for dname in DRIFT_BUCKET_NAMES:
                        for tier_name, _, _, _ in tiers:
                            key   = build_signal_key(side, tier_name, hb, pname, dname)
                            model = self.models.get(key)
                            if model and model.n >= self.min_n:
                                ev = model.ev()
                                if ev > best_cand_ev:
                                    best_cand_ev   = ev
                                    best_cand_name = f"{tier_name} {pname} {dname} n={model.n}"
                print(f"{C.SKIP}  ◂ NO SIGNAL  [{C.WARN}{side}{C.SKIP}]  "
                      f"best EV={C.LOSS}{best_cand_ev:+.4f}{C.SKIP}  {best_cand_name}  {hb}{C.R}")
                continue

            # 確保同一合約同一方向沒有重複掛單
            trade_key = f"{slug}::{side}"
            if any(k.startswith(trade_key) for k in self.open_trades):
                continue

            stake = round(self.capital * self.risk_pct, 4)
            self.trade_id += 1
            trade = PaperTrade(
                id=self.trade_id, slug=slug,
                model_key=best_model.key,
                side=side,
                tier_name=best_model.tier_name,
                entry_ts=ts,
                limit_price=best_model.entry_price,
                stake=stake,
                post_mean_entry=best_model.post_mean,
                ev_entry=best_ev,
            )
            full_key = f"{slug}::{side}::{best_model.tier_name}"
            self.open_trades[full_key] = trade

            side_col = C.PROFIT if side == "YES" else C.BRED
            print(f"\n{C.ORDER}  ▶ ORDER  {side_col}{C.B}{side:>3}{C.R}{C.ORDER}  "
                  f"#{trade.id:<4}  {best_model.tier_name}  "
                  f"{C.LABEL}[{hb}]{C.R}")
            print(f"  {C.LABEL}limit={C.VALUE}{best_model.entry_price:.4f}  "
                  f"{C.LABEL}post={C.VALUE}{best_model.post_mean*100:.1f}%  "
                  f"{C.LABEL}EV={C.SIGNAL}{best_ev:+.4f}  "
                  f"{C.LABEL}n={C.VALUE}{best_model.n}  "
                  f"{C.LABEL}stake={C.VALUE}${stake:.2f}{C.R}")

    # ── 限價成交檢查（跨 tick 跳價也能成交）────────────────────────────

    def _check_fills(self, slug: str, ts: str, yes_p: float,
                     contract: ContractState):
        # YES 和 NO 完全分開的成交邏輯
        #
        # YES 限價 @ 0.85：買 YES，等 yes_p 上升到 0.85
        #   成交條件：max(prev_yes, curr_yes) >= limit
        #
        # NO 限價 @ 0.85（no_p=0.85 = yes_p=0.15）：買 NO，等 yes_p 下跌到 0.15
        #   成交條件：min(prev_yes, curr_yes) <= (1 - limit)
        prev = contract.prev_yes_p()
        if prev is None:
            prev = yes_p

        for key, trade in list(self.open_trades.items()):
            if not key.startswith(f"{slug}::") or trade.filled:
                continue

            filled_now = False

            if trade.side == "YES":
                if max(prev, yes_p) >= trade.limit_price:
                    trade.filled  = True
                    trade.fill_ts = ts
                    filled_now    = True
                    print(f"{C.FILL}   FILL   {C.B}YES{C.R}{C.FILL}  "
                          f"#{trade.id:<4}  "
                          f"limit={trade.limit_price:.4f}  "
                          f"{prev:.4f}{C.BWHT}→{C.R}{C.FILL}{yes_p:.4f}{C.R}  "
                          f"{C.LABEL}{trade.model_key.split('::')[2]}{C.R}")

            elif trade.side == "NO":
                yes_trigger = 1.0 - trade.limit_price
                if min(prev, yes_p) <= yes_trigger:
                    trade.filled  = True
                    trade.fill_ts = ts
                    filled_now    = True
                    print(f"{C.FILL}   FILL   {C.BRED}{C.B} NO{C.R}{C.FILL}  "
                          f"#{trade.id:<4}  "
                          f"limit_no={trade.limit_price:.4f}  "
                          f"no:{1-prev:.4f}{C.BWHT}→{C.R}{C.FILL}{1-yes_p:.4f}{C.R}  "
                          f"{C.LABEL}{trade.model_key.split('::')[2]}{C.R}")

            # 一邊成交後立刻取消反向掛單（避免兩邊都成交）
            if filled_now:
                opposite = "NO" if trade.side == "YES" else "YES"
                cancelled = [
                    k for k in list(self.open_trades.keys())
                    if k.startswith(f"{slug}::{opposite}::") and
                    not self.open_trades[k].filled
                ]
                for k in cancelled:
                    t = self.open_trades.pop(k)
                    print(f"{C.EXPIRE}   CANCEL [{opposite}] #{t.id:<4}  "
                          f"opposite side filled{C.R}")

    # ── 結算 ────────────────────────────────────────────────────────────

    def _settle_contract(self, slug: str, outcome: int, ts: str):
        icon_res  = "YES WIN" if outcome == 1 else "NO  WIN"
        settled_n = 0

        for key in list(self.open_trades.keys()):
            if not key.startswith(f"{slug}::"):
                continue
            trade = self.open_trades.pop(key)
            trade.settle(outcome, ts, capital=self.capital)
            self.closed_trades.append(trade)
            self.capital += trade.pnl
            settled_n += 1

            if trade.expired:
                print(f"{C.EXPIRE}  ○ EXPIR  [{trade.side:>3}]  "
                      f"#{trade.id:<4}  {trade.tier_name}  "
                      f"{C.LABEL}no fill{C.R}")
            else:
                won      = (trade.side == "YES" and outcome == 1) or \
                           (trade.side == "NO"  and outcome == 0)
                res_col  = C.PROFIT if won else C.LOSS
                res_str  = "WIN" if won else "LOSS"
                print(f"\n{res_col}{C.B}  {'◆' if won else '◇'} SETTLE {res_str}  "
                      f"[{trade.side:>3}]{C.R}  "
                      f"#{trade.id:<4}  {trade.tier_name}  "
                      f"{C.LABEL}outcome={C.VALUE}{icon_res}{C.R}")
                print(f"  {C.LABEL}PnL={fmt_pnl(trade.pnl)}  "
                      f"({fmt_pct(trade.pnl_pct_capital)} of capital)  "
                      f"{C.LABEL}equity={C.VALUE}${self.capital:.2f}{C.R}")
            self._write_trade(trade)

        # 滾動更新模型（每個合約只 update 一次，修復雙重計數）
        if slug not in self.updated_slugs:
            contract = self.contracts.get(slug)
            if contract:
                for s in contract.all_samples():
                    for model in self.models.values():
                        if model.matches_sample(s):
                            model.update(outcome)
                for model in self.models.values():
                    self._write_model_update(model, ts, slug)
            self.updated_slugs.add(slug)

        if settled_n > 0:
            self._print_pnl_summary()

    # ── 寫日誌 ──────────────────────────────────────────────────────────

    def _write_trade(self, t: PaperTrade):
        with open(TRADE_LOG, "a", newline="", encoding="utf-8") as f:
            csv.writer(f).writerow([
                t.id, t.slug, t.model_key, t.side, t.tier_name,
                t.entry_ts,
                f"{t.limit_price:.4f}",
                f"{t.stake:.4f}",
                f"{t.post_mean_entry:.4f}",
                f"{t.ev_entry:.6f}",
                t.filled,
                t.fill_ts or "",
                t.exit_ts or "",
                t.outcome if t.outcome is not None else "",
                f"{t.pnl:.6f}" if t.pnl is not None else "",
                f"{t.pnl_pct_capital:.4f}" if t.pnl_pct_capital is not None else "",
            ])

    def _write_model_update(self, m: TierModel, ts: str, slug: str):
        with open(MODEL_LOG, "a", newline="", encoding="utf-8") as f:
            csv.writer(f).writerow([
                ts, m.key, m.side, m.tier_name, m.hbucket,
                m.n, m.wins, m.losses,
                f"{m.post_mean:.4f}", f"{m.ci_lo:.4f}",
                f"{m.ci_hi:.4f}", m.reliability, slug,
            ])

    # ── 顯示 ────────────────────────────────────────────────────────────

    def _print_model_table(self):
        rows = [m for m in self.models.values() if m.n >= self.min_n]
        if not rows:
            print(f"{C.WARN}  [MODEL] No sufficient samples yet{C.R}")
            return
        rows.sort(key=lambda x: -x.ev())
        W = 66
        print(f"\n{C.SEP}  {'─'*W}{C.R}")
        print(f"  {C.HEADER}MODEL RANKING{C.R}  {C.LABEL}{len(rows)} active  top 20 by EV{C.R}")
        print(f"{C.SEP}  {'─'*W}{C.R}")
        hdr = (f"  {C.LABEL}{'TIER':<10} {'SESSION':<10} {'PROGRESS':<14} "
               f"{'DRIFT':<14}  {'N':>5}  {'POST':>6}  {'EV':>8}  {'CI':>12}  CONF{C.R}")
        print(hdr)
        print(f"{C.SEP}  {'─'*W}{C.R}")
        for m in rows[:20]:
            ev   = m.ev()
            ev_c = C.PROFIT if ev > 0.02 else (C.YLW if ev > 0 else C.LOSS)
            s_c  = C.PROFIT if m.side == "YES" else C.BRED
            conf_c = C.PROFIT if m.reliability == "高" else (C.YLW if m.reliability == "中" else C.LOSS)
            print(f"  {s_c}{C.B}{m.side:>3}{C.R}  "
                  f"{C.VALUE}{m.tier_name:<8}{C.R}  "
                  f"{C.LABEL}{m.hbucket[:8]:<8}{C.R}  "
                  f"{C.DIM}{m.pbucket[:12]:<12}{C.R}  "
                  f"{C.DIM}{m.dbucket[:12]:<12}{C.R}  "
                  f"{C.VALUE}{m.n:>5}{C.R}  "
                  f"{fmt_wr(m.post_mean*100):>6}  "
                  f"{ev_c}{ev*100:>+7.2f}%{C.R}  "
                  f"{C.LABEL}{m.ci_lo*100:.1f}~{m.ci_hi*100:.1f}%{C.R}  "
                  f"{conf_c}{m.reliability}{C.R}")
        print(f"{C.SEP}  {'─'*W}{C.R}")

    def _print_pnl_summary(self):
        filled = [t for t in self.closed_trades if t.filled]
        if not filled: return
        wins  = sum(1 for t in filled if (t.pnl or 0) > 0)
        total = sum(t.pnl or 0 for t in self.closed_trades)
        ret   = (self.capital - self.initial_cap) / self.initial_cap * 100
        print(f"\n{sep_line()}")
        print(f"  {C.LABEL}TRADES {C.VALUE}{len(filled)}{C.R}  "
              f"{C.LABEL}WIN RATE {fmt_wr(wins/len(filled)*100)}{C.R}  "
              f"{C.LABEL}PnL {fmt_pnl(total)}{C.R}  "
              f"{C.LABEL}RETURN {fmt_pct(ret)}{C.R}")
        print(sep_line())

    def print_dashboard(self):
        n         = len(self.closed_trades)
        filled    = [t for t in self.closed_trades if t.filled]
        expired   = [t for t in self.closed_trades if t.expired]
        pending   = sum(1 for t in self.open_trades.values() if not t.filled)
        ret_pct   = (self.capital - self.initial_cap) / self.initial_cap * 100
        wins      = sum(1 for t in filled if (t.pnl or 0) > 0)
        wr        = wins / len(filled) * 100 if filled else 0
        total_pnl = sum(t.pnl or 0 for t in self.closed_trades)
        fill_rate = len(filled) / n * 100 if n else 0
        now_str   = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

        yes_f  = [t for t in filled if t.side == "YES"]
        no_f   = [t for t in filled if t.side == "NO"]
        yes_wr = sum(1 for t in yes_f if (t.pnl or 0) > 0) / len(yes_f) * 100 if yes_f else 0
        no_wr  = sum(1 for t in no_f  if (t.pnl or 0) > 0) / len(no_f)  * 100 if no_f  else 0
        recent = [t for t in self.closed_trades if t.filled][-6:]

        W = 66
        eq_col = C.PROFIT if ret_pct >= 0 else C.LOSS

        print(f"\n{C.BG_BLK}{C.HEADER}  ▌POLYMARKET QUANT ENGINE v3{C.R}  "
              f"{C.LABEL}{now_str}{C.R}")
        print(sep_line("═"))

        # Equity row
        print(f"  {C.LABEL}EQUITY    "
              f"{C.LABEL}START {C.VALUE}${self.initial_cap:>9.2f}  "
              f"{C.LABEL}NOW   {eq_col}{C.B}${self.capital:>10.4f}{C.R}  "
              f"{C.LABEL}RETURN  {fmt_pct(ret_pct)}{C.R}")

        # Order stats row
        print(f"  {C.LABEL}ORDERS    "
              f"{C.LABEL}TOTAL {C.VALUE}{n:>5}  "
              f"{C.LABEL}FILLED {C.VALUE}{len(filled):>4} {C.LABEL}({fill_rate:.0f}%)  "
              f"{C.LABEL}EXPIRED {C.VALUE}{len(expired):>4}  "
              f"{C.LABEL}PENDING {C.VALUE}{pending:>3}{C.R}")

        # Win rate row
        print(f"  {C.LABEL}WIN RATE  "
              f"{C.PROFIT}YES {fmt_wr(yes_wr)} {C.LABEL}({len(yes_f)} fills)    "
              f"{C.BRED} NO {fmt_wr(no_wr)} {C.LABEL}({len(no_f)} fills)    "
              f"{C.LABEL}OVERALL {fmt_wr(wr)}{C.R}")

        # PnL row
        print(f"  {C.LABEL}P&L       "
              f"{C.LABEL}TOTAL {fmt_pnl(total_pnl)}  "
              f"{C.LABEL}AVG/TRADE {fmt_pnl(total_pnl/len(filled)) if filled else C.NEUTRAL+'N/A'+C.R}{C.R}")

        if recent:
            print(sep_line("─"))
            print(f"  {C.LABEL}RECENT TRADES{C.R}")
            for t in reversed(recent):
                won    = (t.side == "YES" and t.outcome == 1) or (t.side == "NO" and t.outcome == 0)
                s_col  = C.PROFIT if t.side == "YES" else C.BRED
                r_col  = C.PROFIT if won else C.LOSS
                ts_str = t.fill_ts[:16] if t.fill_ts else t.entry_ts[:16]
                print(f"  {r_col}{'▲' if won else '▼'}{C.R}  "
                      f"{s_col}{C.B}{t.side:>3}{C.R}  "
                      f"{C.LABEL}{ts_str}  "
                      f"{C.VALUE}{t.tier_name:<10}{C.R}  "
                      f"{fmt_pnl(t.pnl or 0)}  "
                      f"{fmt_pct(t.pnl_pct_capital or 0)}")

        print(sep_line("═"))

    # ── 主迴圈 ──────────────────────────────────────────────────────────

    def run(self, backfill_rows: list[dict] = None):
        if backfill_rows:
            self.backfill(backfill_rows)
            try:
                with open(self.csv_file, "r", encoding="utf-8") as f:
                    self.last_row = max(0, sum(1 for _ in f) - 1)
            except Exception:
                pass
        print(f"\n{C.SEP}  ════════════════════════════════════════════════════════════════{C.R}")
        print(f"  {C.HEADER}▌ POLYMARKET QUANT ENGINE v3{C.R}  {C.LABEL}initializing...{C.R}")
        print(f"  {C.LABEL}models    {C.VALUE}{len(self.models)} active  = {len(YES_PRICE_TIERS)+len(NO_PRICE_TIERS)} tiers × {len(HOUR_BUCKETS)} sessions × {len(PROGRESS_BUCKETS)} progress × 3 drift{C.R}")
        print(f"  {C.LABEL}capital   {C.VALUE}${self.capital:.2f}  {C.LABEL}risk/bet {C.VALUE}{self.risk_pct*100:.1f}%{C.R}")
        print(f"  {C.LABEL}min ev    {C.VALUE}{self.min_ev:.4f}  {C.LABEL}min n {C.VALUE}{self.min_n}{C.R}")
        skip_est = sorted((h - 5) % 24 for h in self.SKIP_UTC_HOURS)
        print(f"  {C.WARN}skip hrs  UTC {sorted(self.SKIP_UTC_HOURS)} = EST {skip_est}{C.R}")
        print(f"  {C.SEP}════════════════════════════════════════════════════════════════{C.R}\n")

        total_new      = 0
        last_model     = 0
        last_dashboard = 0
        while True:
            rows = self._read_new_rows()
            total_new += len(rows)
            for row in rows:
                self.process_row(row)

            now = time.time()
            if now - last_dashboard > DASHBOARD_SEC:
                ts_now = datetime.now().strftime("%H:%M:%S")
                active = sum(1 for c in self.contracts.values() if not c.closed)
                print(f"{C.SEP}  ◈  {C.LABEL}{ts_now}  "
                      f"{C.VALUE}+{len(rows)} rows  {C.LABEL}active={C.VALUE}{active}  "
                      f"{C.LABEL}open={C.VALUE}{len(self.open_trades)}  "
                      f"{C.LABEL}total_rows={C.VALUE}{total_new}{C.R}",
                      flush=True)
                self.print_dashboard()
                last_dashboard = now

            if now - last_model > 300:
                self._print_model_table()
                last_model = now


            time.sleep(REFRESH_SEC)


# ─────────────────────────────────────────────────────────────────────────────
# CLI
# ─────────────────────────────────────────────────────────────────────────────

def main():
    ap = argparse.ArgumentParser(
        description="Polymarket Paper Trading Engine v3",
        formatter_class=argparse.RawTextHelpFormatter,
    )
    ap.add_argument("--csv",      default=CSV_FILE)
    ap.add_argument("--capital",  type=float, default=1000.0)
    ap.add_argument("--risk",     type=float, default=0.03,
                    help="每筆固定 risk（預設 0.03=3%%）")
    ap.add_argument("--alpha0",   type=float, default=2.0)
    ap.add_argument("--beta0",    type=float, default=2.0)
    ap.add_argument("--min-ev",   type=float, default=0.005)
    ap.add_argument("--min-n",    type=int,   default=10)
    ap.add_argument("--backfill", action="store_true")
    ap.add_argument("--skip-hours", default="13,14,20",
                    help="UTC hours to skip (default: 13,14,20 = US market open/close)")
    ap.add_argument("--debug",    action="store_true")
    args = ap.parse_args()

    # 從 papertrade_log.csv 還原上次的本金
    starting_capital = args.capital
    if os.path.exists(TRADE_LOG):
        try:
            with open(TRADE_LOG, "r", encoding="utf-8") as f:
                log_rows = list(csv.DictReader(f))
            if log_rows:
                cap = args.capital
                for r in log_rows:
                    try: cap += float(r['pnl'])
                    except: pass
                if cap != args.capital:
                    print(f"   從上次本金還原: ${args.capital:.2f} → ${cap:.4f}")
                    starting_capital = cap
        except Exception as e:
            print(f"    還原本金失敗: {e}")

    engine = PaperTradingEngine(
        csv_file = args.csv,
        capital  = starting_capital,
        risk_pct = args.risk,
        alpha0   = args.alpha0,
        beta0    = args.beta0,
        min_ev   = args.min_ev,
        min_n    = args.min_n,
        debug    = args.debug,
    )

    backfill_rows = None
    if args.backfill:
        try:
            with open(args.csv, "r", encoding="utf-8") as f:
                backfill_rows = list(csv.DictReader(f))
            print(f"   載入 {len(backfill_rows)} 筆歷史資料")
        except FileNotFoundError:
            print(f"    找不到 {args.csv}")

    # 允許用 CLI 自訂跳過時段
    try:
        skip = {int(x.strip()) for x in args.skip_hours.split(",") if x.strip()}
        engine.SKIP_UTC_HOURS = skip
    except Exception:
        pass
    try:
        engine.run(backfill_rows=backfill_rows)
    except KeyboardInterrupt:
        print(f"\n\n 停止")
        engine._print_model_table()
        engine.print_dashboard()
        sys.exit(0)


if __name__ == "__main__":
    main()